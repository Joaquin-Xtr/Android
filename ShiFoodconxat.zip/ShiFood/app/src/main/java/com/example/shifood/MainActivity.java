package com.example.shifood;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText txtUsuario, txtPassword;
    private Button btnInicio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtUsuario = findViewById(R.id.txtUsuario);
        txtPassword = findViewById(R.id.txtPassword);
    }
    public void validar(View view) {
        /*
         *Si los datos corresponden
         * Mostrar mensaje en Toast
         */

        if (txtUsuario.getText().toString().equals("Joaquin")
                && txtPassword.getText().toString().equals("123456")) {

            Toast mensaje = Toast.makeText(getApplicationContext(), "¡Inicio Exitoso!", Toast.LENGTH_LONG);
            mensaje.show();

            Intent intent = new Intent(this, InterfazUsuario1.class);
            startActivity(intent);
        } else {
            Toast mensaje = Toast.makeText(getApplicationContext(), "Error de Ingreso", Toast.LENGTH_LONG);
            mensaje.show();

        }
    }
    public void registro(View view) {
        Intent intent = new Intent(this, RegistroUsuario.class);
        startActivity(intent);
    }
}
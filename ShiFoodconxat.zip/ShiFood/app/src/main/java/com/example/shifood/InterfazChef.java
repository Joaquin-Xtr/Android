package com.example.shifood;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toolbar;

public class InterfazChef extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interfaz_chef);


    }

    public void recetario1(View view) {
        Intent intent = new Intent(this, Recetas1.class);
        startActivity(intent);
    }

}
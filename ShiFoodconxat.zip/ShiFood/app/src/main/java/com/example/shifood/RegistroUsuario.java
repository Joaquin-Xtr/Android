package com.example.shifood;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegistroUsuario extends AppCompatActivity {
    EditText nombre = null;
    EditText contra1 = null;
    EditText contra2 = null;
    EditText correo = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_usuario);
        nombre = findViewById(R.id.txtNombre1);
        contra1 = findViewById(R.id.txtpassword1);
       contra2 = findViewById(R.id.txtrepassword2);
        correo = findViewById(R.id.txtCorreo);
    }
    public void Ingresar(View viewn){

        SQLiteDB objDb= new SQLiteDB(this);
        String nom="", pass1="",pass2="",correo1="";
        nom=nombre.getText().toString();
        pass1=contra1.getText().toString();
        pass2=contra2.getText().toString();
        correo1=correo.getText().toString();
        objDb.insertarDatos(nom, pass1, pass2, correo1);
        Toast mensaje = Toast.makeText(getApplicationContext(), "¡Cuenta Registrada Correctamente!", Toast.LENGTH_LONG);
        mensaje.show();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }
}
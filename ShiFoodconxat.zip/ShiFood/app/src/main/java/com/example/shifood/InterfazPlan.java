package com.example.shifood;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.icu.text.RelativeDateTimeFormatter;
import android.net.Uri;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;

import org.imaginativeworld.whynotimagecarousel.CarouselItem;
import org.imaginativeworld.whynotimagecarousel.ImageCarousel;

import java.util.ArrayList;
import java.util.List;

public class InterfazPlan extends AppCompatActivity {
    private Button btnPortal;
    private String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interfaz_plan);

        //ImageCarousel carousel = findViewById(R.id.carrusel);
        List<CarouselItem> list = new ArrayList<>();

        list.add(new CarouselItem("https://www.google.com/imgres?imgurl=https%3A%2F%2Flookaside.fbsbx.com%2Flookaside%2Fcrawler%2Fmedia%2F%3Fmedia_id%3D3693812217342155&imgrefurl=https%3A%2F%2Fwww.facebook.com%2Feldelgato2%2Fposts%2Fvalorant-michis%2F3693812414008802%2F&tbnid=gDsm4J4fWutjLM&vet=12ahUKEwiDxu_-1IvxAhVyuJUCHSRfDiQQMygAegUIARCsAQ..i&docid=RdV0iu1LmrhHrM&w=682&h=682&q=gato%20valorant&client=opera-gx&ved=2ahUKEwiDxu_-1IvxAhVyuJUCHSRfDiQQMygAegUIARCsAQ"));

        list.add(new CarouselItem(R.drawable.plan_1mes, "" ));
        list.add(new CarouselItem(R.drawable.plan_3meses, "" ));
        list.add(new CarouselItem(R.drawable.plan_6meses, "" ));
        //carousel.addData(list);





        //Botón para pagar
        url="https://www.webpay.cl/portalpagodirecto/pages/index.jsf";
        btnPortal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
    }

    public void interfapr1(View view) {
        Intent intent = new Intent(this, InterfazUsuarioPrem.class);
        startActivity(intent);
    }
}